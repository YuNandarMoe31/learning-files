Tables
------
# categories
- id
- name
- created_at
- updated_at

# products
- id
- name
- created_at
- updated_at

# cateogry_product
- category_id
- product_id

# Todo
- Category CRUD
- Product CRUD

Remark
--------
CRUD include search, pagination, delete confirmation, validation
